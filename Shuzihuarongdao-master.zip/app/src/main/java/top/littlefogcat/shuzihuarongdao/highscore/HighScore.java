/*
 * 2020.5.26
 * heliru
 * 数字华容道
 * 用于小组作业
 */
package top.littlefogcat.shuzihuarongdao.highscore;


public class HighScore {
    public long useTime;
    public long time;
    public String name = "匿名";
    public int useStep;
}
